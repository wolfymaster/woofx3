import fs from 'fs';

async function postFunctions() {
    const formData = new FormData();

    const file = new File(["This is file content"], "myfile.txt", {
        type: "text/plain",
        lastModified: Date.now()
    });

    formData.append('file', file);
    formData.append('somethingelse', 'hello');

    try {
        const response = await fetch('http://barkloader.local.woofx3.tv/functions', {
            method: 'POST',
            body: formData,
        });

        return await response.json();
    } catch (err) {
        throw new Error("busted");
    }
}

async function uploadZipFileFromPath(filePath: string, endpoint: string): Promise<any> {
    try {
        // Check if file exists and is a zip file
        if (!fs.existsSync(filePath)) {
            throw new Error(`File not found: ${filePath}`);
        }

        if (!filePath.endsWith('.zip')) {
            throw new Error('File must be a ZIP file');
        }

        // Create form data
        const form = new FormData();
        const fileStream = fs.createReadStream(filePath);
        const fileName = filePath.split('/').pop() || 'upload.zip';

        form.append('zipFile', fileStream, {
            filename: fileName,
            contentType: 'application/zip'
        });

        // Make the request
        const response = await fetch(endpoint, {
            method: 'POST',
            body: form,
            headers: {
                ...form.getHeaders()
            }
        });

        if (!response.ok) {
            throw new Error(`Upload failed: ${response.status} ${response.statusText}`);
        }

        return await response.json();
    } catch (error) {
        console.error('Upload error:', error);
        throw error;
    }
}


async function patchFunctions() {
    try {
        const response = await fetch('http://barkloader.local.woofx3.tv/functions', {
            method: 'patch',
        });

        return await response.json();
    } catch (err) {
        throw new Error("busted");
    }

}

// console.log(await postFunctions());

console.log(await uploadZipFileFromPath('', 'http://barkloader.local.woofx3.tv/functions'));